#pragma once

#include "targetver.h"
#include <GL/freeglut.h>
#include <time.h>
#include <stdlib.h>
#include <iostream>
#include <ctime>
#include <math.h> 
// funckja i przestrzen nazw do obslugi muzyki